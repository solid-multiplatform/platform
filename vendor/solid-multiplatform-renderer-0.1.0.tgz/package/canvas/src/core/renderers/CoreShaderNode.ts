import { UpdateType, type CoreNode } from '../CoreNode.js';
import type { Stage } from '../Stage.js';

export interface AdvShaderProp<T = any, Props = Record<string, unknown>> {
  /**
   * default value
   */
  default: T;
  resolve?: (this: AdvShaderProp<T, Props>, value: T, props: Props) => T;
  transform?: (start: T, end: T, progress: number) => T;
}

export type AdvancedShaderProp<T = any, Props = Record<string, unknown>> =
  | (AdvShaderProp<T, Props> & {
      set: (value: T, props: Props) => void;
      get: (props: Props) => T;
    })
  | (AdvShaderProp<T, Props> & { set?: never; get?: never });

export type ShaderProp<T, Props> = T | AdvancedShaderProp<T, Props>;

export type ShaderProps<Props> = {
  [K in keyof Props]: ShaderProp<Props[K], Props>;
};

export function isAdvancedShaderProp(obj: any): obj is AdvancedShaderProp {
  return obj !== null && typeof obj === 'object' && obj.default !== undefined;
}

export function resolveShaderProps(
  props: Record<string, unknown>,
  propsConfig: ShaderProps<Record<string, unknown>>,
) {
  for (const key in propsConfig) {
    if (!isAdvancedShaderProp(propsConfig[key]) && props[key] === undefined) {
      props[key] = propsConfig[key];
      continue;
    }

    const pConfig = propsConfig[key]! as AdvancedShaderProp;
    const hasValue = props[key] !== undefined;

    if (pConfig.resolve !== undefined) {
      props[key] = pConfig.resolve!(props[key], props);
      continue;
    }
    if (hasValue && pConfig.set !== undefined) {
      pConfig.set(props[key], props);
      continue;
    }
    if (hasValue) {
      continue;
    }

    if (props[key] === undefined && pConfig.get === undefined) {
      /**
       * Array defaults are copied so per-node writes (advanced `set` props
       * mutate the resolved array in place) never reach the shader type's
       * module-level literal, which every node of that type shares.
       */
      const def = pConfig.default;
      props[key] = Array.isArray(def) === true ? def.slice() : def;
      continue;
    }
    props[key] = pConfig.get!(props);
  }
}

/**
 * CoreShaderType is a template for ShaderTypes the renderer.
 * You could view a ShaderType as a configuration object that contains methods,
 * and values that you can use to alter the way a node is drawn by the Renderer.
 */
export interface CoreShaderType<Props extends object = any> {
  /**
   * Values you use to draw the Shader
   */
  props?: ShaderProps<Props>;
  /**
   * used for making a cache key to check for reusability, currently only used for webgl ShaderTypes but might be needed for other types of renderer
   */
  getCacheMarkers?: (props: Props) => string;
  /**
   * timer that updates every loop, by default uses the stage elapsed time If you want to do a special calculation you can define a function.
   * When you calculate your own value you can use the Stage timing values deltaTime, lastFrameTime, and currentFrameTime;
   * the function also receives the node's resolved shader props. The value
   * reaches the shader as `u_time`, which is binary16 in a Mali-400 fragment
   * shader: return something small (e.g. a cycle position in [0, 1)) rather
   * than a millisecond clock, which overflows 65504 after about a minute.
   */
  time?: boolean | ((stage: Stage, props: Props) => number);
}

/**
 * CoreShaderNode is a base class that manages the shader prop values.
 * When a prop is being updated the CoreShaderNode will notify either the associated CoreNode,
 * or the Stage that there has been a change and a new render of the scene.
 */
export class CoreShaderNode<Props extends object = Record<string, unknown>> {
  readonly stage: Stage;
  readonly shaderType: CoreShaderType<Props>;
  protected propsConfig: ShaderProps<Props> | undefined;
  readonly resolvedProps: Props | undefined = undefined;
  protected definedProps: Props | undefined = undefined;
  protected node: CoreNode | null = null;
  readonly time: CoreShaderType['time'] = undefined;
  update: (() => void) | undefined = undefined;
  private updater: ((node: CoreNode) => void) | undefined = undefined;
  /**
   * The shader-value cache key currently held by this node (set by the
   * subclass `update()` after the most recent successful value resolution).
   * Tracked on the base so {@link detachNode} can release it on teardown.
   */
  valueKey = '';
  private _valueKeyCache = '';
  private _valueKeyDirty = true;
  private _lastW = 0;
  private _lastH = 0;

  constructor(
    readonly shaderKey: string,
    type: CoreShaderType<Props>,
    stage: Stage,
    props?: Props,
  ) {
    this.stage = stage;
    this.shaderType = type;
    this.time = type.time;

    if (props !== undefined) {
      /**
       * props are already resolved by shadermanager
       */
      this.resolvedProps = props;
      this.defineProps(props);
    }
  }

  private defineProps(props: Props) {
    const definedProps = {};
    for (const key in props) {
      const propConfig = this.shaderType.props![key];
      const isAdvancedProp = isAdvancedShaderProp(propConfig);

      Object.defineProperty(definedProps, key, {
        get: () => {
          return this.resolvedProps![key as keyof Props];
        },
        set: (value) => {
          // this.resolvedProps![key as keyof Props] = value;
          if (isAdvancedProp === true && propConfig.resolve !== undefined) {
            this.resolvedProps![key] = propConfig.resolve(
              value,
              this.resolvedProps as Record<string, unknown>,
            );
          } else if (isAdvancedProp === true && propConfig.set !== undefined) {
            propConfig.set(
              value,
              this.resolvedProps as Record<string, unknown>,
            );
          } else {
            this.resolvedProps![key] = value;
          }
          this._valueKeyDirty = true;

          if (this.update !== undefined && this.node !== null) {
            this.node.setUpdateType(UpdateType.RecalcUniforms);
          } else {
            this.stage.requestRender();
          }
        },
      });
    }
    this.definedProps = definedProps as Props;
  }

  attachNode(node: CoreNode) {
    this.node = node;
  }

  /**
   * Install the value-key cached `update()` for a shader type that has an
   * updater. The updater only runs for a value key not seen before; nodes with
   * equal keys share the resulting values object by reference (the WebGL
   * batcher relies on that — see WebGlShaderProgram.bindRenderOp). Without
   * props there is no key to cache on, so the updater runs on every update.
   *
   * Called by the backend subclass, whose {@link resetValues} and
   * {@link adoptValues} manage its values object (WebGL: `uniforms`,
   * Canvas: `computed`).
   */
  protected installUpdater(updater: (node: CoreNode) => void): void {
    this.updater = updater;

    if (this.props === undefined) {
      this.update = () => {
        this.updater!(this.node as CoreNode);
      };
      return;
    }

    this.update = () => {
      const prevKey = this.valueKey;
      const key = (this.valueKey = this.createValueKey());

      if (prevKey === key) {
        return;
      }

      const shManager = this.stage.shManager;
      if (prevKey.length > 0) {
        shManager.mutateShaderValueUsage(prevKey, -1);
      }

      const cached = shManager.getShaderValues(key);
      if (cached !== undefined) {
        this.adoptValues(cached);
        return;
      }

      const values = this.resetValues();
      this.updater!(this.node as CoreNode);
      shManager.setShaderValues(key, values);
    };
  }

  /**
   * Replace the backend's values object with a fresh, empty one for the
   * updater to fill, and return it.
   */
  protected resetValues(): Record<string, unknown> {
    return {};
  }

  /** Take a cached values object shared by nodes with the same value key. */
  protected adoptValues(_values: Record<string, unknown>): void {
    // no-op
  }

  /**
   * Release this node's currently-held shader-value cache entry so the shader
   * manager's idle `cleanup()` can reclaim it, and detach from the owning node.
   *
   * Called from {@link CoreNode.destroy}. Mirrors the `prevKey` release done on
   * every value-key change in the subclass `update()`; without it a destroyed
   * node's last value-cache entry stays pinned at usage >= 1 forever and can
   * never be evicted.
   */
  detachNode() {
    if (this.valueKey.length > 0) {
      this.stage.shManager.mutateShaderValueUsage(this.valueKey, -1);
      this.valueKey = '';
    }
    this.node = null;
  }

  createValueKey() {
    if (
      this._valueKeyDirty === false &&
      this.node !== null &&
      this.node.w === this._lastW &&
      this.node.h === this._lastH
    ) {
      return this._valueKeyCache;
    }

    let valueKey = '';
    for (const key in this.resolvedProps) {
      valueKey += `${key}:${this.resolvedProps[key]!};`;
    }
    valueKey += `node-width:${this.node!.w}`;
    valueKey += `node-height:${this.node!.h}`;

    this._valueKeyCache = valueKey;
    this._valueKeyDirty = false;
    this._lastW = this.node!.w;
    this._lastH = this.node!.h;

    return valueKey;
  }

  get props(): Props | undefined {
    return this.definedProps;
  }

  set props(props: Props | undefined) {
    if (props === undefined) {
      return;
    }
    for (const key in props) {
      this.props![key] = props[key];
    }
  }
}
